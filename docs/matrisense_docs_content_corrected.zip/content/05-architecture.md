# Architecture

MatriSense uses a layered web architecture designed to keep AI language tasks separate from safety-critical triage decisions.

### Frontend Layer
*   **Patient Panel:** Profile editor, symptom reporting, confirmation, follow-up, result page, and triage history.
*   **Health Worker Panel:** Dashboard, patient list, triage case list, case detail, status update, referral notes, and regional referral panels if enabled.
*   **Admin Panel:** Documentation visibility controls, scheduling, and future verification workflows.
*   **Docs Page:** Judge-facing product, technical, safety, and evidence documentation.

### API Layer
*   **Auth API:** Login, registration, role-based access, and current-user checks.
*   **Patient API:** Patient profile, history, optional records, and profile snapshots.
*   **Triage API:** Session creation, extraction, confirmation, follow-up, rule execution, explanation, and result retrieval.
*   **Worker API:** Case list, case detail, status update, patient list, and regional filters.
*   **Referral / Hospital API:** Referral notes, seeded hospitals, nearby or same-district lookup, and hospital assignment if enabled.
*   **Docs API:** Documentation status, live stats, Markdown content, and evidence file access.

### AI and Safety Layer
*   **LLM Extractor:** Converts Bangla symptom descriptions into structured symptom codes.
*   **Follow-up Selector:** Chooses a small number of approved questions based on missing danger-sign information.
*   **Rule Engine:** Decides LOW, MEDIUM, or HIGH risk using structured case facts.
*   **Rule-aware RAG:** Retrieves allowed care guidance based on symptoms, evidence tags, risk level, and guidance type.
*   **Explanation Service:** Uses the fixed decision and retrieved guidance to produce simple Bangla output.
*   **Safety Validator:** Blocks diagnosis, medicine advice, risk downgrade, unsupported steps, and unsafe contradictions.

### Data Layer
*   **MongoDB Collections:** Users, Patients, TriageSessions, ReferralNotes, AuditLogs, Hospitals, and DocsConfig where available.
*   **Static/Curated Content:** Knowledge cards, evidence references, docs Markdown files, and demo content.
*   **Future Vector Store:** Metadata-filtered embeddings for maternal health guideline chunks.
