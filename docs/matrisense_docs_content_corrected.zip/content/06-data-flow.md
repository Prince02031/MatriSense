# Data Flow

The MatriSense triage journey turns a Bangla symptom report into a structured case for the mother and health worker.

### Patient Intake
1.  **Profile Context:** The system uses pregnancy stage, gestational week, known risk factors, last checkup date, emergency contact, and optional location/document context when available.
2.  **Symptom Entry:** The mother reports symptoms in Bangla text or voice-transcribed text.
3.  **AI Extraction:** The LLM extracts structured symptoms, severity, duration, and uncertain fields. A keyword fallback can support the demo if the LLM fails.
4.  **Human Confirmation:** The mother confirms or edits the extracted symptoms before the system runs the final triage logic.

### Triage Processing
5.  **Follow-up Questions:** The system asks 1–3 approved questions for missing danger-sign information.
6.  **Case State Builder:** Profile context, confirmed symptoms, severity, duration, and follow-up answers are combined into one case state.
7.  **Rule Engine:** Deterministic maternal danger-sign rules classify risk as LOW, MEDIUM, or HIGH.
8.  **Decision Builder:** Rule events are merged into a final decision with risk level, reasons, matched rules, evidence tags, recommended action, and allowed guidance type.

### Guidance and Review
9.  **Rule-aware RAG:** The retriever selects only guidance cards allowed by the fixed risk decision.
10. **LLM Explanation:** The LLM turns the fixed decision and retrieved guidance into simple Bangla instructions.
11. **Safety Validation:** The output is checked before display. Unsafe outputs are replaced with fallback templates.
12. **Patient Result:** The mother sees risk, explanation, next steps, monitoring points, warning signs, and a safety disclaimer.
13. **Health Worker Case:** The structured case appears in the health worker dashboard for review, status update, referral note, or hospital assignment if available.
