# AI Layer

### Symptom Extraction
Patients report symptoms in natural Bangla. The LLM extracts structured symptoms, severity, duration, and uncertain fields using an approved symptom code list. The system may use keyword fallback extraction for safety and demo reliability. The mother confirms the extracted symptoms before triage continues.

### Follow-up Logic
Follow-up questions are selected from an approved question bank rather than generated freely. The system asks only a few questions that affect risk interpretation, such as blurred vision with headache, bleeding with abdominal pain, repeated vomiting, difficulty breathing, fainting, swelling, or reduced fetal movement.

### Clinical Triage
The rule engine receives structured case facts, not raw Bangla text. It checks maternal danger signs and risk modifiers to classify urgency as LOW, MEDIUM, or HIGH. The rule engine is the safety-critical decision layer; the LLM is not allowed to decide or downgrade medical risk.

### Rule-Aware RAG
After the risk decision is fixed, RAG retrieves care guidance cards that match the symptoms, evidence tags, risk level, and allowed guidance type. HIGH-risk cases cannot retrieve self-care-first guidance. LOW-risk cases can receive self-care guidance but must include warning signs.

### LLM Explanation
The LLM explains the fixed decision and retrieved guidance in simple Bangla. It should not invent extra medical steps, diagnose disease, prescribe medicine, or change the risk level. Health worker summaries can include the original symptoms, follow-up answers, matched rules, and patient-facing guidance shown.

### Safety Validator
Before the mother sees the response, the safety validator checks for diagnosis, medicine or dosage advice, false reassurance, risk downgrade, unsupported steps, and missing warning signs. If output is unsafe, the system shows a predefined safe fallback based on the rule-engine risk level.
