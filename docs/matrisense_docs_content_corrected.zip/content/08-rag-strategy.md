# RAG Strategy

### Current MVP: Rule-Aware Guidance Cards & Evidence Tags
MatriSense currently uses curated guidance cards with metadata such as symptom codes, allowed risk levels, evidence tags, source labels, and guidance type. The rule engine first decides the risk level and allowed guidance type. RAG then retrieves only matching guidance.

*   **RAG does not decide urgency:** The rule engine decides LOW, MEDIUM, or HIGH risk.
*   **LLM only explains the fixed decision:** The LLM receives the fixed decision and retrieved cards, then produces Bangla guidance within those boundaries.
*   **Evidence Library connection:** The Evidence Library shows public references and internal summaries used to design the cards, rules, and safety constraints.

### Retrieval Safety Rules
*   HIGH-risk cases retrieve urgent escalation guidance only.
*   MEDIUM-risk cases retrieve health-worker contact guidance plus safe temporary monitoring advice.
*   LOW-risk cases may retrieve self-care guidance but must include escalation triggers.
*   Retrieved guidance must avoid diagnosis, medicine dosage, false reassurance, and unsupported home remedies.

### In Progress: Vector RAG with Metadata Filtering
The planned vector RAG upgrade will embed guideline chunks or knowledge cards and search them with strict metadata filters such as symptom, risk level, guidance type, evidence tag, and pregnancy context. Vector retrieval will support better evidence coverage, but it will not override the rule engine.

### Future Roadmap: GraphRAG
GraphRAG is planned as a structured relation layer connecting `symptom` → `danger sign` → `triage rule` → `risk level` → `allowed action` → `evidence source`. This can improve explainability and retrieval precision while preserving the existing safety boundary.
